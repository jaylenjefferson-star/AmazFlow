"use strict";
const DEFAULT_API = "https://5jsi2v2k35.execute-api.us-east-1.amazonaws.com";
function el(id) { return document.getElementById(id); }
async function currentTabOrigin() {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab?.url)
        return null;
    try {
        return new URL(tab.url).origin;
    }
    catch {
        return null;
    }
}
async function refreshStatus() {
    const { apiBase, token } = await chrome.storage.local.get(["apiBase", "token"]);
    el("apiBase").value = apiBase || DEFAULT_API;
    el("token").value = token || "";
    el("tokenStatus").textContent = token ? "Token saved" : "No token saved yet";
    const origin = await currentTabOrigin();
    const siteStatus = el("siteStatus");
    const siteButton = el("enableSite");
    if (!origin) {
        siteStatus.textContent = "Open a target tab to enable this site.";
        siteButton.disabled = true;
        return;
    }
    const granted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
    siteStatus.textContent = granted ? `Enabled on ${origin}` : `Not enabled on ${origin}`;
    siteButton.disabled = granted;
    siteButton.textContent = granted ? "Enabled" : `Enable on ${origin}`;
}
el("save").addEventListener("click", async () => {
    const apiBase = el("apiBase").value.trim() || DEFAULT_API;
    const token = el("token").value.trim();
    await chrome.storage.local.set({ apiBase, token });
    await refreshStatus();
});
el("enableSite").addEventListener("click", async () => {
    const origin = await currentTabOrigin();
    if (!origin)
        return;
    await chrome.permissions.request({ origins: [`${origin}/*`] });
    await refreshStatus();
});
refreshStatus();
