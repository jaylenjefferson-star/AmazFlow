"use strict";
const POPUP_DEFAULT_API = "https://5jsi2v2k35.execute-api.us-east-1.amazonaws.com";
const CONNECT_URL = "https://amazflow.com/agent-authorize/";
function el(id) { return document.getElementById(id); }
function escapeHtml(value) {
    return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}
function renderActivity(log) {
    const container = el("activityLog");
    if (!log.length) {
        container.innerHTML = `<p class="activity-empty">Nothing yet -- this fills in as soon as a workflow step runs on a tab you've enabled.</p>`;
        return;
    }
    container.innerHTML = log
        .slice(0, 8)
        .map((entry) => {
        const time = new Date(entry.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
        const selectorLine = entry.selector ? `<div class="sel">${escapeHtml(entry.selector)}</div>` : "";
        return `<div class="activity-row ${entry.ok ? "activity-ok" : "activity-fail"}">
        <div class="op"><b>${entry.ok ? "✓" : "✕"} ${escapeHtml(entry.operation)}</b><span>${time}</span></div>
        ${selectorLine}
        <div class="detail">${escapeHtml(entry.detail)}</div>
      </div>`;
    })
        .join("");
}
async function currentTabOrigin() {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab?.url)
        return null;
    try {
        return new URL(tab.url).origin;
    }
    catch {
        return null;
    }
}
async function refreshStatus() {
    const { agentToken, agentName, tenantId, lastConnectionError } = await chrome.storage.local.get(["agentToken", "agentName", "tenantId", "lastConnectionError"]);
    const connected = Boolean(agentToken);
    el("disconnectedView").style.display = connected ? "none" : "block";
    el("connectedView").style.display = connected ? "block" : "none";
    const connectError = el("connectError");
    connectError.textContent = typeof lastConnectionError === "string" ? lastConnectionError : "";
    connectError.style.display = lastConnectionError ? "block" : "none";
    if (!connected)
        return;
    el("agentNameLabel").textContent = agentName || "Browser Agent";
    el("agentTenantLabel").textContent = `Connected · ${tenantId || "unknown org"}`;
    const origin = await currentTabOrigin();
    const siteStatus = el("siteStatus");
    const siteButton = el("enableSite");
    if (!origin) {
        siteStatus.textContent = "Open a target tab to enable this site.";
        siteButton.disabled = true;
        return;
    }
    const granted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
    siteStatus.textContent = granted ? `Enabled on ${origin}` : `Not enabled on ${origin}`;
    siteButton.disabled = granted;
    siteButton.textContent = granted ? "Enabled" : `Enable on ${origin}`;
    // What this agent is holding a lease on right now. Until the agent claimed its work there
    // was nothing to show here -- a task was either invisible or already in the history -- so a
    // step that hung looked identical to no work existing at all.
    const runningEl = el("runningTask");
    const { currentTask } = await chrome.storage.local.get(["currentTask"]);
    const active = currentTask;
    if (active && new Date(active.claimExpiresAt).getTime() > Date.now()) {
        const secondsLeft = Math.max(0, Math.round((new Date(active.claimExpiresAt).getTime() - Date.now()) / 1000));
        runningEl.style.display = "block";
        runningEl.innerHTML = `<div class="op"><span class="dot"></span>Running ${escapeHtml(active.operation)}</div>
      <div class="meta">Step ${escapeHtml(active.stepId)} of run ${escapeHtml(active.runId)}</div>
      ${active.selector ? `<div class="meta">${escapeHtml(active.selector)}</div>` : ""}
      <div class="meta">Claimed by this browser · ${secondsLeft}s left on the lease</div>`;
    }
    else {
        runningEl.style.display = "none";
    }
    const { activityLog } = await chrome.storage.local.get(["activityLog"]);
    renderActivity(Array.isArray(activityLog) ? activityLog : []);
}
// Live-updates the log while the popup is open and a poll happens to land mid-view, instead of
// only reflecting whatever the log looked like at the moment the popup was opened.
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && (changes.activityLog || changes.currentTask))
        refreshStatus();
});
el("connect").addEventListener("click", async () => {
    const { apiBase } = await chrome.storage.local.get(["apiBase"]);
    if (!apiBase)
        await chrome.storage.local.set({ apiBase: POPUP_DEFAULT_API });
    const tab = await chrome.tabs.create({ url: CONNECT_URL });
    if (tab.id)
        await chrome.storage.local.set({ pendingConnectTabId: tab.id });
    window.close();
});
el("disconnect").addEventListener("click", async () => {
    await chrome.storage.local.remove(["agentToken", "agentId", "agentName", "tenantId", "lastConnectionError", "userId", "userRole", "currentTask"]);
    await refreshStatus();
});
el("enableSite").addEventListener("click", async () => {
    const origin = await currentTabOrigin();
    if (!origin)
        return;
    await chrome.permissions.request({ origins: [`${origin}/*`] });
    await refreshStatus();
});
refreshStatus();
