const DEFAULT_API = "https://5jsi2v2k35.execute-api.us-east-1.amazonaws.com";
const CONNECT_URL = "https://amazflow.com/agent-authorize/";
function el(id) { return document.getElementById(id); }
async function currentTabOrigin() {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab?.url)
        return null;
    try {
        return new URL(tab.url).origin;
    }
    catch {
        return null;
    }
}
async function refreshStatus() {
    const { agentToken, agentName, tenantId } = await chrome.storage.local.get(["agentToken", "agentName", "tenantId"]);
    const connected = Boolean(agentToken);
    el("disconnectedView").style.display = connected ? "none" : "block";
    el("connectedView").style.display = connected ? "block" : "none";
    if (!connected)
        return;
    el("agentNameLabel").textContent = agentName || "Browser Agent";
    el("agentTenantLabel").textContent = `Connected · ${tenantId || "unknown org"}`;
    const origin = await currentTabOrigin();
    const siteStatus = el("siteStatus");
    const siteButton = el("enableSite");
    if (!origin) {
        siteStatus.textContent = "Open a target tab to enable this site.";
        siteButton.disabled = true;
        return;
    }
    const granted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
    siteStatus.textContent = granted ? `Enabled on ${origin}` : `Not enabled on ${origin}`;
    siteButton.disabled = granted;
    siteButton.textContent = granted ? "Enabled" : `Enable on ${origin}`;
}
el("connect").addEventListener("click", async () => {
    const { apiBase } = await chrome.storage.local.get(["apiBase"]);
    if (!apiBase)
        await chrome.storage.local.set({ apiBase: DEFAULT_API });
    const tab = await chrome.tabs.create({ url: CONNECT_URL });
    if (tab.id)
        await chrome.storage.local.set({ pendingConnectTabId: tab.id });
    window.close();
});
el("disconnect").addEventListener("click", async () => {
    await chrome.storage.local.remove(["agentToken", "agentId", "agentName", "tenantId"]);
    await refreshStatus();
});
el("enableSite").addEventListener("click", async () => {
    const origin = await currentTabOrigin();
    if (!origin)
        return;
    await chrome.permissions.request({ origins: [`${origin}/*`] });
    await refreshStatus();
});
refreshStatus();
