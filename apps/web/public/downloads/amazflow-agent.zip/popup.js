"use strict";
const el = (id) => document.getElementById(id);
const escapeHtml = (v) => v.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const clock = (iso) => (iso ? new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "—");
const STATE_COPY = {
    signed_out: { text: "Not connected", cls: "off" },
    connected: { text: "Ready", cls: "ok" },
    working: { text: "Working", cls: "work" },
    error: { text: "Needs attention", cls: "bad" },
};
async function render() {
    el("version").textContent = `v${chrome.runtime.getManifest().version}`;
    const { session, agent, status, currentActivity } = (await chrome.storage.local.get(["session", "agent", "status", "currentActivity"]));
    const connected = Boolean(session && agent);
    el("signedOut").style.display = connected ? "none" : "block";
    el("signedIn").style.display = connected ? "block" : "none";
    if (!connected) {
        const detail = status?.detail;
        const banner = el("signInError");
        banner.textContent = detail ?? "";
        banner.style.display = detail ? "block" : "none";
        return;
    }
    const state = status?.state === "signed_out" ? "connected" : (status?.state ?? "connected");
    const copy = STATE_COPY[state];
    el("stateLine").className = `state ${copy.cls}`;
    el("stateText").textContent = copy.text;
    el("stateDetail").textContent = status?.detail ?? "";
    el("userLabel").textContent = session.email;
    el("orgLabel").textContent = agent.tenantId;
    el("agentLabel").textContent = agent.name;
    el("heartbeatLabel").textContent = clock(status?.lastHeartbeatAt);
    el("reconnect").style.display = state === "error" ? "block" : "none";
    // What the agent is doing, in the words the person who started it would use.
    const taskCard = el("taskCard");
    if (currentActivity) {
        const progress = currentActivity.stepNumber && currentActivity.stepCount
            ? `Step ${currentActivity.stepNumber} of ${currentActivity.stepCount}`
            : "";
        taskCard.style.display = "block";
        taskCard.innerHTML = `<div class="op">${escapeHtml(currentActivity.workflowName)}</div>
      <div class="meta">${escapeHtml(currentActivity.stepName)}${progress ? ` · ${progress}` : ""}</div>
      ${currentActivity.where ? `<div class="meta">on ${escapeHtml(currentActivity.where)}</div>` : ""}`;
    }
    else {
        taskCard.style.display = "none";
    }
    const resultCard = el("resultCard");
    const last = status?.lastResult;
    if (last) {
        resultCard.style.display = "block";
        resultCard.className = `result ${last.ok ? "good" : "bad"}`;
        // Falls back to the raw action only for entries an older build recorded.
        const title = last.workflowName ?? last.operation;
        const detail = last.ok ? (last.stepName ?? "Completed") : last.detail;
        resultCard.innerHTML = `<b>${last.ok ? "✓" : "✕"} ${escapeHtml(title)}</b> · ${clock(last.at)}<div class="meta">${escapeHtml(detail)}</div>`;
    }
    else {
        resultCard.style.display = "none";
    }
}
chrome.storage.onChanged.addListener((_changes, area) => { if (area === "local")
    void render(); });
// The lease countdown is the one thing that changes with no storage write behind it.
setInterval(() => { void render(); }, 1000);
el("connect").addEventListener("click", async () => {
    const button = el("connect");
    const banner = el("signInError");
    const email = el("email").value.trim();
    const password = el("password").value;
    if (!email || !password) {
        banner.textContent = "Enter your AmazFlow email and password.";
        banner.style.display = "block";
        return;
    }
    button.disabled = true;
    button.textContent = "Connecting…";
    banner.style.display = "none";
    const tenant = el("tenant").value.trim();
    const response = await chrome.runtime.sendMessage({ type: "AMAZFLOW_CONNECT", email, password, tenantId: tenant || undefined });
    // The password only ever existed in this popup's memory and the message to the worker; drop it
    // as soon as the attempt resolves either way.
    el("password").value = "";
    button.disabled = false;
    button.textContent = "Connect this browser";
    if (!response?.ok) {
        banner.textContent = response?.error || "Could not connect. Try again.";
        banner.style.display = "block";
        return;
    }
    await render();
});
// --- Entry point: start a workflow from here instead of the web app -----------------------
async function loadWorkflows() {
    const list = el("workflowList");
    list.innerHTML = `<p class="empty">Loading your workflows…</p>`;
    const response = await chrome.runtime.sendMessage({ type: "AMAZFLOW_WORKFLOWS" });
    if (!response?.ok) {
        list.innerHTML = `<p class="empty">${escapeHtml(response?.error ?? "Couldn’t load your workflows.")}</p>`;
        return;
    }
    const workflows = response.workflows;
    if (!workflows.length) {
        list.innerHTML = `<p class="empty">No workflows are assigned to you yet.</p>`;
        return;
    }
    list.innerHTML = workflows
        .map((w) => `<button class="wf-start" data-id="${escapeHtml(w.id)}"><b>${escapeHtml(w.name)}</b>${w.summary ? `<small>${escapeHtml(w.summary)}</small>` : ""}</button>`)
        .join("");
    for (const button of Array.from(list.querySelectorAll(".wf-start"))) {
        button.addEventListener("click", async () => {
            const original = button.innerHTML;
            const banner = el("startError");
            button.disabled = true;
            button.innerHTML = "<b>Starting…</b>";
            const started = await chrome.runtime.sendMessage({ type: "AMAZFLOW_START", workflowId: button.dataset.id });
            button.disabled = false;
            if (!started?.ok) {
                button.innerHTML = original;
                // Preflight already translated "which agent is missing" into something actionable.
                banner.textContent = started?.error ?? "Couldn’t start that workflow.";
                banner.style.display = "block";
                return;
            }
            banner.style.display = "none";
            button.innerHTML = "<b>Started ✓</b>";
            setTimeout(() => { button.innerHTML = original; }, 2500);
        });
    }
}
el("disconnect").addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "AMAZFLOW_DISCONNECT" });
    await render();
});
el("reconnect").addEventListener("click", async () => {
    const button = el("reconnect");
    button.disabled = true;
    button.textContent = "Reconnecting…";
    const response = await chrome.runtime.sendMessage({ type: "AMAZFLOW_RECONNECT" });
    button.disabled = false;
    button.textContent = "Reconnect this browser";
    if (!response?.ok) {
        const banner = el("stateDetail");
        banner.textContent = response?.error || "Could not reconnect.";
    }
    await render();
});
// A super admin can name the organization this browser should act for; everyone else is bound to
// the organization on their own account and never sees the field.
el("email").addEventListener("blur", () => {
    el("orgWrap").style.display = /@amazflow\.com$/i.test(el("email").value.trim()) ? "block" : "none";
});
void render();
void loadWorkflows();
