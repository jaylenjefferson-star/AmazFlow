"use strict";
const el = (id) => document.getElementById(id);
const escapeHtml = (v) => v.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const clock = (iso) => (iso ? new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "—");
const STATE_COPY = {
    signed_out: { text: "Not connected", cls: "off" },
    connected: { text: "Connected · watching for work", cls: "ok" },
    working: { text: "Running a workflow step", cls: "work" },
    error: { text: "Needs attention", cls: "bad" },
};
async function render() {
    el("version").textContent = `v${chrome.runtime.getManifest().version}`;
    const { session, agent, status, currentTask } = (await chrome.storage.local.get(["session", "agent", "status", "currentTask"]));
    const connected = Boolean(session && agent);
    el("signedOut").style.display = connected ? "none" : "block";
    el("signedIn").style.display = connected ? "block" : "none";
    if (!connected) {
        const detail = status?.detail;
        const banner = el("signInError");
        banner.textContent = detail ?? "";
        banner.style.display = detail ? "block" : "none";
        return;
    }
    const state = status?.state === "signed_out" ? "connected" : (status?.state ?? "connected");
    const copy = STATE_COPY[state];
    el("stateLine").className = `state ${copy.cls}`;
    el("stateText").textContent = copy.text;
    el("stateDetail").textContent = status?.detail ?? "";
    el("userLabel").textContent = session.email;
    el("orgLabel").textContent = agent.tenantId;
    el("agentLabel").textContent = agent.name;
    el("heartbeatLabel").textContent = clock(status?.lastHeartbeatAt);
    el("reconnect").style.display = state === "error" ? "block" : "none";
    const taskCard = el("taskCard");
    if (currentTask && new Date(currentTask.claimExpiresAt).getTime() > Date.now()) {
        const left = Math.max(0, Math.round((new Date(currentTask.claimExpiresAt).getTime() - Date.now()) / 1000));
        taskCard.style.display = "block";
        taskCard.innerHTML = `<div class="op">${escapeHtml(currentTask.operation)}</div>
      <div class="meta">Step ${escapeHtml(currentTask.stepId)} · run ${escapeHtml(currentTask.runId)}</div>
      ${currentTask.selector ? `<div class="meta">${escapeHtml(currentTask.selector)}</div>` : ""}
      ${currentTask.url ? `<div class="meta">${escapeHtml(currentTask.url)}</div>` : ""}
      <div class="meta">Lease held by this browser · ${left}s left</div>`;
    }
    else {
        taskCard.style.display = "none";
    }
    const resultCard = el("resultCard");
    const last = status?.lastResult;
    if (last) {
        resultCard.style.display = "block";
        resultCard.className = `result ${last.ok ? "good" : "bad"}`;
        resultCard.innerHTML = `<b>${last.ok ? "✓" : "✕"} ${escapeHtml(last.operation)}</b> · ${clock(last.at)}<div class="meta">${escapeHtml(last.detail)}</div>`;
    }
    else {
        resultCard.style.display = "none";
    }
}
chrome.storage.onChanged.addListener((_changes, area) => { if (area === "local")
    void render(); });
// The lease countdown is the one thing that changes with no storage write behind it.
setInterval(() => { void render(); }, 1000);
el("connect").addEventListener("click", async () => {
    const button = el("connect");
    const banner = el("signInError");
    const email = el("email").value.trim();
    const password = el("password").value;
    if (!email || !password) {
        banner.textContent = "Enter your AmazFlow email and password.";
        banner.style.display = "block";
        return;
    }
    button.disabled = true;
    button.textContent = "Connecting…";
    banner.style.display = "none";
    const tenant = el("tenant").value.trim();
    const response = await chrome.runtime.sendMessage({ type: "AMAZFLOW_CONNECT", email, password, tenantId: tenant || undefined });
    // The password only ever existed in this popup's memory and the message to the worker; drop it
    // as soon as the attempt resolves either way.
    el("password").value = "";
    button.disabled = false;
    button.textContent = "Connect this browser";
    if (!response?.ok) {
        banner.textContent = response?.error || "Could not connect. Try again.";
        banner.style.display = "block";
        return;
    }
    await render();
});
el("disconnect").addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ type: "AMAZFLOW_DISCONNECT" });
    await render();
});
el("reconnect").addEventListener("click", async () => {
    const button = el("reconnect");
    button.disabled = true;
    button.textContent = "Reconnecting…";
    const response = await chrome.runtime.sendMessage({ type: "AMAZFLOW_RECONNECT" });
    button.disabled = false;
    button.textContent = "Reconnect this browser";
    if (!response?.ok) {
        const banner = el("stateDetail");
        banner.textContent = response?.error || "Could not reconnect.";
    }
    await render();
});
// A super admin can name the organization this browser should act for; everyone else is bound to
// the organization on their own account and never sees the field.
el("email").addEventListener("blur", () => {
    el("orgWrap").style.display = /@amazflow\.com$/i.test(el("email").value.trim()) ? "block" : "none";
});
void render();
