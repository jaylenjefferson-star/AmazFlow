const DEFAULT_API = "https://5jsi2v2k35.execute-api.us-east-1.amazonaws.com";
const allowed = new Set(["READ_TEXT", "CLICK", "TYPE", "SELECT", "VERIFY_TEXT", "SET_EMPLOYEE_STATUS"]);
async function getConfig() {
    const stored = await chrome.storage.local.get(["apiBase", "agentToken"]);
    return { apiBase: stored.apiBase || DEFAULT_API, agentToken: stored.agentToken || "" };
}
async function hasHostPermission(origin) {
    return chrome.permissions.contains({ origins: [`${origin}/*`] });
}
chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create("amazflow-poll", { periodInMinutes: 0.25 });
    chrome.alarms.create("amazflow-heartbeat", { periodInMinutes: 2 });
});
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
    const { pendingConnectTabId } = await chrome.storage.local.get(["pendingConnectTabId"]);
    if (!pendingConnectTabId || tabId !== pendingConnectTabId || !changeInfo.url)
        return;
    let code = null;
    try {
        code = new URL(changeInfo.url).searchParams.get("code");
    }
    catch {
        return;
    }
    if (!code)
        return;
    await chrome.storage.local.remove(["pendingConnectTabId"]);
    const { apiBase } = await getConfig();
    try {
        const response = await fetch(`${apiBase}/agent-authorizations/${encodeURIComponent(code)}/exchange`, { method: "POST" });
        const body = await response.json();
        if (!response.ok)
            throw new Error(body.error || "Exchange failed");
        await chrome.storage.local.set({ agentToken: body.token, agentId: body.agentId, tenantId: body.tenantId });
    }
    catch (error) {
        console.error("AmazFlow agent connect failed", error);
    }
});
chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === "amazflow-heartbeat") {
        const { apiBase, agentToken } = await getConfig();
        if (!agentToken)
            return;
        await fetch(`${apiBase}/agent/heartbeat`, {
            method: "POST",
            headers: { "content-type": "application/json", "X-AmazFlow-Agent-Token": agentToken },
            body: JSON.stringify({ version: chrome.runtime.getManifest().version }),
        }).catch(() => undefined);
        return;
    }
    if (alarm.name !== "amazflow-poll")
        return;
    const { apiBase, agentToken } = await getConfig();
    if (!agentToken)
        return;
    const tasks = await fetch(`${apiBase}/agent/tasks`, { headers: { "X-AmazFlow-Agent-Token": agentToken } })
        .then((r) => (r.ok ? r.json() : []))
        .catch(() => []);
    const task = tasks.find((t) => new Date(t.expiresAt).getTime() > Date.now() && allowed.has(t.operation));
    if (!task)
        return;
    const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!activeTab?.id || !activeTab.url)
        return;
    const origin = new URL(activeTab.url).origin;
    if (!(await hasHostPermission(origin)))
        return;
    await chrome.scripting.executeScript({ target: { tabId: activeTab.id }, files: ["content.js"] }).catch(() => undefined);
    const response = await chrome.tabs.sendMessage(activeTab.id, { type: "AMAZFLOW_TASK", task }).catch((error) => ({ ok: false, error: String(error) }));
    const result = response?.ok ? { ok: true, ...response.result } : { ok: false, error: response?.error || "Unknown error" };
    await fetch(`${apiBase}/agent/tasks/${task.id}/result`, {
        method: "POST",
        headers: { "content-type": "application/json", "X-AmazFlow-Agent-Token": agentToken },
        body: JSON.stringify(result),
    }).catch(() => undefined);
});
