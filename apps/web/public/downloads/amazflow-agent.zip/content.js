"use strict";
const one = (selector) => {
    if (typeof selector !== "string")
        throw new Error("A scoped selector is required");
    const nodes = document.querySelectorAll(selector);
    if (nodes.length !== 1)
        throw new Error(`Expected one authorized target, found ${nodes.length}`);
    return nodes[0];
};
// Strong-identifier check: before touching a real record, re-reads whatever field the page uses
// to display which record is currently selected and refuses to act if it doesn't match what the
// workflow expects -- catches both a wrong-record mixup and a stale page (the operator navigated
// to a different record after the run started, before this step actually got to run).
function assertTarget(input) {
    const identifierSelector = input.identifierSelector != null ? String(input.identifierSelector) : null;
    const expectedIdentifier = input.expectedIdentifier != null ? String(input.expectedIdentifier).trim() : "";
    if (!identifierSelector || !expectedIdentifier)
        return; // no identifier configured for this step -- nothing to check
    const el = one(identifierSelector);
    const actual = (el instanceof HTMLInputElement ||
        el instanceof HTMLTextAreaElement ||
        el instanceof HTMLSelectElement
        ? el.value
        : el.innerText).toString().trim();
    if (actual !== expectedIdentifier) {
        throw new Error(`Target mismatch: expected record "${expectedIdentifier}" but the page shows "${actual}" -- refusing to act on the wrong record.`);
    }
}
function waitFor(selector, timeoutMs) {
    return new Promise((resolve, reject) => {
        const found = document.querySelector(selector);
        if (found)
            return resolve(found);
        const observer = new MutationObserver(() => {
            const el = document.querySelector(selector);
            if (el) {
                observer.disconnect();
                resolve(el);
            }
        });
        observer.observe(document.body, { childList: true, subtree: true, attributes: true });
        setTimeout(() => { observer.disconnect(); reject(new Error(`Timed out waiting for "${selector}"`)); }, timeoutMs);
    });
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== "AMAZFLOW_TASK")
        return;
    execute(message.task).then(result => sendResponse({ ok: true, result })).catch(error => sendResponse({ ok: false, error: String(error) }));
    return true;
});
async function execute(task) {
    const { operation, input } = task;
    if (operation === "READ_TEXT")
        return { text: one(input.selector).innerText };
    if (operation === "CLICK") {
        one(input.selector).click();
        return { clicked: true };
    }
    if (operation === "TYPE") {
        const el = one(input.selector);
        el.focus();
        el.value = String(input.value ?? "");
        el.dispatchEvent(new Event("input", { bubbles: true }));
        return { typed: true };
    }
    if (operation === "SELECT") {
        const el = one(input.selector);
        el.value = String(input.value);
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return { selected: el.value };
    }
    if (operation === "CHECK") {
        const el = one(input.selector);
        el.checked = Boolean(input.checked ?? true);
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return { checked: el.checked };
    }
    if (operation === "SCROLL_TO") {
        one(input.selector).scrollIntoView({ block: "center" });
        return { scrolled: true };
    }
    if (operation === "WAIT_FOR") {
        await waitFor(String(input.selector), Number(input.timeoutMs) || 5000);
        return { appeared: true };
    }
    if (operation === "VERIFY_TEXT") {
        const actual = one(input.selector).innerText.trim();
        return { verified: actual === String(input.expected), actual };
    }
    if (operation === "SET_EMPLOYEE_STATUS") {
        assertTarget(input);
        const selector = String(input.selector ?? '[data-amazflow="employee-status"]');
        const el = one(selector);
        el.value = String(input.status);
        el.dispatchEvent(new Event("change", { bubbles: true }));
        // Re-observes the field immediately after writing it, rather than assuming the write
        // succeeded -- this is what the workflow's own verify step actually checks downstream.
        return { status: el.value };
    }
    throw new Error(`Operation ${operation} is not supported in this agent build`);
}
